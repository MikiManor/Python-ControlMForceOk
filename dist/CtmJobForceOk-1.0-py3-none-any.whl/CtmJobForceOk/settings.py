def init():
    global varName
    global commandToExecute
    global orderID
    varName = ''
    orderID = ''